import * as vscode from 'vscode';

export interface PetState {
  name: string;
  petType: 'cat' | 'dog' | 'bunny';
  hp: number;
  hunger: number;
  fun: number;
  rest: number;
  age: number;           // days alive
  totalSaves: number;    // files saved while pet is alive
  lastSeen: number;      // timestamp — used to calc offline decay
}

const STATE_KEY = 'vscode-pet.state';

const DEFAULT_STATE: PetState = {
  name: 'Nibbles',
  petType: 'cat',
  hp: 100,
  hunger: 80,
  fun: 70,
  rest: 60,
  age: 0,
  totalSaves: 0,
  lastSeen: Date.now(),
};

export function loadState(
  context: vscode.ExtensionContext,
  reset = false
): PetState {
  if (reset) {
    return { ...DEFAULT_STATE, lastSeen: Date.now() };
  }

  const config = vscode.workspace.getConfiguration('vscode-pet');
  const saved = context.globalState.get<PetState>(STATE_KEY);

  const base: PetState = saved
    ? { ...DEFAULT_STATE, ...saved }
    : { ...DEFAULT_STATE };

  // Apply name/type from settings
  base.name = config.get<string>('petName', base.name);
  base.petType = config.get<'cat' | 'dog' | 'bunny'>('petType', base.petType);

  // Apply offline decay (max 8 hours counted)
  if (saved) {
    const hoursAway = Math.min(
      (Date.now() - saved.lastSeen) / 3_600_000,
      8
    );
    const decayRate = config.get<number>('decayRate', 1);
    const decay = Math.floor(hoursAway * 5 * decayRate);
    base.hunger = clamp(base.hunger - decay);
    base.fun    = clamp(base.fun    - decay);
    base.rest   = clamp(base.rest   - Math.floor(decay / 2));
    base.hp     = clamp(base.hp     - (base.hunger < 20 ? Math.floor(hoursAway * 2) : 0));
  }

  base.lastSeen = Date.now();
  return base;
}

export function saveState(
  context: vscode.ExtensionContext,
  state: PetState
): void {
  context.globalState.update(STATE_KEY, {
    ...state,
    lastSeen: Date.now(),
  });
}

function clamp(v: number): number {
  return Math.max(0, Math.min(100, v));
}
