import * as vscode from 'vscode';
import { PetState } from './petState';
import { getPetSvg } from './petSprites';

export function getWebviewContent(
  webview: vscode.Webview,
  extensionUri: vscode.Uri,
  state: PetState
): string {
  const petSvg = getPetSvg(state.petType, (state.hp + state.fun + state.rest + state.hunger) / 4);
  const nonce = getNonce();

  return /* html */ `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="Content-Security-Policy"
    content="default-src 'none';
             style-src 'nonce-${nonce}' https://fonts.googleapis.com;
             font-src https://fonts.gstatic.com;
             img-src ${webview.cspSource} data:;
             script-src 'nonce-${nonce}';">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <title>Pet Companion</title>
  <style nonce="${nonce}">
    @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;700&display=swap');

    :root {
      --pet-color: #4ec9b0;
      --pet-dark: #3ab8a0;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: 'JetBrains Mono', var(--vscode-font-family), monospace;
      background: var(--vscode-sideBar-background);
      color: var(--vscode-foreground);
      padding: 12px 10px;
      font-size: 11px;
      overflow-x: hidden;
    }

    .pet-name {
      color: var(--pet-color);
      font-weight: 700;
      font-size: 12px;
      letter-spacing: 0.06em;
      text-align: center;
      margin-bottom: 10px;
    }

    .pet-wrap {
      width: 100%;
      max-width: 160px;
      margin: 0 auto 10px;
      position: relative;
    }

    .pet-wrap svg {
      width: 100%;
      height: auto;
      display: block;
    }

    #petContainer {
      transition: transform 0.1s;
    }
    #petContainer.bounce { animation: bounce 0.4s ease 3; }
    @keyframes bounce {
      0%,100% { transform: translateY(0); }
      50% { transform: translateY(-8px); }
    }

    .bubble {
      position: absolute;
      top: 0; right: -4px;
      background: var(--vscode-input-background);
      border: 1px solid var(--vscode-input-border, #454545);
      border-radius: 8px 8px 8px 2px;
      padding: 3px 7px;
      font-size: 10px;
      white-space: nowrap;
      display: none;
    }

    .mood-badge {
      background: var(--vscode-input-background);
      border: 1px solid var(--vscode-input-border, #454545);
      border-radius: 4px;
      padding: 4px 8px;
      text-align: center;
      color: #dcdcaa;
      margin-bottom: 12px;
      font-size: 10px;
    }

    .stats { margin-bottom: 12px; }

    .stat-row {
      display: flex;
      align-items: center;
      gap: 6px;
      margin-bottom: 6px;
    }

    .stat-label {
      font-size: 9px;
      color: var(--vscode-descriptionForeground);
      width: 34px;
      text-transform: uppercase;
      letter-spacing: 0.07em;
      flex-shrink: 0;
    }

    .stat-bar {
      flex: 1;
      height: 4px;
      background: var(--vscode-input-background, #3c3c3c);
      border-radius: 2px;
      overflow: hidden;
    }

    .stat-fill {
      height: 100%;
      border-radius: 2px;
      transition: width 0.4s ease;
    }

    .stat-val {
      width: 26px;
      text-align: right;
      font-size: 9px;
      color: var(--vscode-descriptionForeground);
      flex-shrink: 0;
    }

    .actions { display: flex; flex-direction: column; gap: 5px; margin-bottom: 12px; }

    button {
      background: var(--vscode-button-secondaryBackground, #3c3c3c);
      border: 1px solid var(--vscode-input-border, #454545);
      border-radius: 4px;
      color: var(--vscode-foreground);
      cursor: pointer;
      font-family: inherit;
      font-size: 10px;
      padding: 6px 8px;
      text-align: left;
      display: flex;
      align-items: center;
      gap: 6px;
      width: 100%;
      transition: background 0.15s, border-color 0.15s;
    }

    button:hover {
      background: var(--vscode-list-hoverBackground);
      border-color: var(--vscode-focusBorder, #007acc);
    }

    button:active { transform: scale(0.98); }

    .log {
      background: var(--vscode-terminal-background, #1e1e1e);
      border: 1px solid var(--vscode-input-border, #454545);
      border-radius: 4px;
      padding: 6px 8px;
      font-size: 9px;
      max-height: 80px;
      overflow-y: auto;
      color: var(--vscode-terminal-foreground, #d4d4d4);
    }

    .log-line { margin-bottom: 2px; line-height: 1.5; }
    .log-line.ok { color: var(--pet-color); }
    .log-line.warn { color: #ffbe5c; }

    .divider {
      border: none;
      border-top: 1px solid var(--vscode-input-border, #3c3c3c);
      margin: 10px 0;
    }

    .age-line {
      font-size: 9px;
      color: var(--vscode-descriptionForeground);
      text-align: center;
      margin-top: 8px;
    }
  </style>
</head>
<body>

  <div class="pet-name" id="petName">${escapeHtml(state.name)}.EXE</div>

  <div class="pet-wrap">
    <div id="petContainer">${petSvg}</div>
    <div class="bubble" id="bubble"></div>
  </div>

  <div class="mood-badge" id="moodBadge">😸 Happy coder</div>

  <div class="stats">
    <div class="stat-row">
      <span class="stat-label">HP</span>
      <div class="stat-bar"><div class="stat-fill" id="hpBar" style="width:${state.hp}%;background:#4ec9b0;"></div></div>
      <span class="stat-val" id="hpVal">${state.hp}</span>
    </div>
    <div class="stat-row">
      <span class="stat-label">Hunger</span>
      <div class="stat-bar"><div class="stat-fill" id="hngBar" style="width:${state.hunger}%;background:#dcdcaa;"></div></div>
      <span class="stat-val" id="hngVal">${state.hunger}</span>
    </div>
    <div class="stat-row">
      <span class="stat-label">Fun</span>
      <div class="stat-bar"><div class="stat-fill" id="funBar" style="width:${state.fun}%;background:#c586c0;"></div></div>
      <span class="stat-val" id="funVal">${state.fun}</span>
    </div>
    <div class="stat-row">
      <span class="stat-label">Rest</span>
      <div class="stat-bar"><div class="stat-fill" id="restBar" style="width:${state.rest}%;background:#ce9178;"></div></div>
      <span class="stat-val" id="restVal">${state.rest}</span>
    </div>
  </div>

  <div class="actions">
    <button onclick="action('feed')">🍣 feed() — restore hunger</button>
    <button onclick="action('play')">🎮 play() — boost fun</button>
    <button onclick="action('sleep')">🌙 sleep() — restore rest</button>
    <button onclick="action('code')">💻 code() — bonus XP</button>
  </div>

  <hr class="divider">
  <div class="log" id="log">
    <div class="log-line ok">🐾 ${escapeHtml(state.name)} is online.</div>
  </div>
  <div class="age-line" id="ageLine">Age: ${state.age} days · Saves: ${state.totalSaves}</div>

  <script nonce="${nonce}">
    const vscode = acquireVsCodeApi();

    let state = ${JSON.stringify(state)};

    const moods = [
      [80, '😸 Happy coder'],
      [60, '😊 Doing okay'],
      [40, '😐 Needs attention'],
      [20, '😿 Feeling sad'],
      [0,  '💤 Very tired'],
    ];

    function clamp(v) { return Math.max(0, Math.min(100, v)); }

    function getMood() {
      const avg = (state.hp + state.hunger + state.fun + state.rest) / 4;
      return (moods.find(m => avg >= m[0]) || moods[moods.length - 1])[1];
    }

    function updateUI() {
      document.getElementById('hpBar').style.width  = state.hp + '%';
      document.getElementById('hngBar').style.width = state.hunger + '%';
      document.getElementById('funBar').style.width = state.fun + '%';
      document.getElementById('restBar').style.width = state.rest + '%';
      document.getElementById('hpVal').textContent  = state.hp;
      document.getElementById('hngVal').textContent = state.hunger;
      document.getElementById('funVal').textContent = state.fun;
      document.getElementById('restVal').textContent = state.rest;
      document.getElementById('moodBadge').textContent = getMood();
      document.getElementById('ageLine').textContent =
        'Age: ' + state.age + ' days · Saves: ' + state.totalSaves;

      const hp = document.getElementById('hpBar');
      hp.style.background = state.hp > 60 ? '#4ec9b0' : state.hp > 30 ? '#dcdcaa' : '#f44747';
    }

    function showBubble(msg, ms = 2500) {
      const b = document.getElementById('bubble');
      b.textContent = msg;
      b.style.display = 'block';
      clearTimeout(window._bubbleTimer);
      window._bubbleTimer = setTimeout(() => b.style.display = 'none', ms);
    }

    function bounce() {
      const c = document.getElementById('petContainer');
      c.classList.remove('bounce');
      void c.offsetWidth;
      c.classList.add('bounce');
    }

    function appendLog(msg, cls = '') {
      const log = document.getElementById('log');
      const line = document.createElement('div');
      line.className = 'log-line' + (cls ? ' ' + cls : '');
      line.textContent = msg;
      log.appendChild(line);
      log.scrollTop = log.scrollHeight;
    }

    function action(type) {
      switch (type) {
        case 'feed':
          if (state.hunger >= 100) { showBubble('Too full! 🙅'); return; }
          state.hunger = clamp(state.hunger + 20);
          state.hp     = clamp(state.hp + 5);
          bounce(); showBubble('Yummy! 🍣');
          appendLog('> pet.feed() — hunger +20, hp +5', 'ok');
          break;
        case 'play':
          if (state.rest < 15) { showBubble('Too tired! 😴'); return; }
          state.fun    = clamp(state.fun + 25);
          state.rest   = clamp(state.rest - 15);
          state.hunger = clamp(state.hunger - 10);
          bounce(); showBubble('Wheee! 🎮');
          appendLog('> pet.play() — fun +25, rest -15', 'ok');
          break;
        case 'sleep':
          if (state.rest >= 100) { showBubble('Not sleepy! 😺'); return; }
          state.rest = clamp(state.rest + 30);
          state.hp   = clamp(state.hp + 8);
          showBubble('Zzz... 💤');
          appendLog('> pet.sleep() — rest +30, hp +8', 'ok');
          break;
        case 'code':
          state.fun    = clamp(state.fun + 10);
          state.hp     = clamp(state.hp + 3);
          state.rest   = clamp(state.rest - 8);
          state.hunger = clamp(state.hunger - 5);
          bounce(); showBubble('npm run purr 🐾');
          appendLog('> pet.code() — fun +10, hp +3', 'ok');
          break;
      }
      updateUI();
      vscode.postMessage({ type: 'stateUpdate', state });
    }

    // Blink eyes
    function blink() {
      const eL = document.getElementById('eyeL');
      const eR = document.getElementById('eyeR');
      if (eL && eR) {
        eL.setAttribute('ry', '1'); eR.setAttribute('ry', '1');
        setTimeout(() => { eL.removeAttribute('ry'); eR.removeAttribute('ry'); }, 120);
      }
      setTimeout(blink, 2500 + Math.random() * 3000);
    }
    blink();

    // Tail wag
    let tailDir = 1, tailAngle = 0;
    function wagTail() {
      tailAngle += tailDir * 1.5;
      if (tailAngle > 12 || tailAngle < -12) tailDir *= -1;
      const tail = document.getElementById('tail');
      if (tail) tail.setAttribute('transform', 'rotate(' + tailAngle + ', 30, 72)');
      requestAnimationFrame(wagTail);
    }
    wagTail();

    // Listen for messages from the extension host
    window.addEventListener('message', e => {
      const msg = e.data;
      switch (msg.type) {
        case 'feed':  action('feed');  break;
        case 'play':  action('play');  break;
        case 'sleep': action('sleep'); break;
        case 'decay': {
          const rate = msg.payload?.rate ?? 1;
          state.hunger = clamp(state.hunger - Math.round(2 * rate));
          state.fun    = clamp(state.fun    - Math.round(1 * rate));
          state.rest   = clamp(state.rest   - Math.round(1 * rate));
          if (state.hunger < 20) state.hp = clamp(state.hp - 2);
          updateUI();
          vscode.postMessage({ type: 'stateUpdate', state });
          break;
        }
        case 'onSave': {
          state.totalSaves++;
          state.fun = clamp(state.fun + 2);
          appendLog('📝 File saved! fun +2', 'ok');
          updateUI();
          vscode.postMessage({ type: 'stateUpdate', state });
          break;
        }
        case 'log': {
          appendLog(msg.payload?.message ?? '', 'ok');
          break;
        }
        case 'reset': {
          if (msg.payload) {
            state = msg.payload;
            updateUI();
            appendLog('🔄 Pet reset!', 'warn');
          }
          break;
        }
      }
    });
  </script>
</body>
</html>`;
}

function getNonce(): string {
  let text = '';
  const possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  for (let i = 0; i < 32; i++) {
    text += possible.charAt(Math.floor(Math.random() * possible.length));
  }
  return text;
}

function escapeHtml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
