import * as vscode from 'vscode';
import { PetViewProvider } from './petViewProvider';
import { PetState, loadState, saveState } from './petState';

let petProvider: PetViewProvider | undefined;
let decayInterval: ReturnType<typeof setInterval> | undefined;

export function activate(context: vscode.ExtensionContext) {
  console.log('🐾 Pet Companion extension activated!');

  // Load or initialise pet state
  let state: PetState = loadState(context);

  // Register the sidebar webview provider
  petProvider = new PetViewProvider(context.extensionUri, state, (updated) => {
    state = updated;
    saveState(context, state);
  });

  context.subscriptions.push(
    vscode.window.registerWebviewViewProvider(PetViewProvider.viewType, petProvider)
  );

  // Register commands
  context.subscriptions.push(
    vscode.commands.registerCommand('vscode-pet.feed', () => {
      petProvider?.sendAction('feed');
    }),
    vscode.commands.registerCommand('vscode-pet.play', () => {
      petProvider?.sendAction('play');
    }),
    vscode.commands.registerCommand('vscode-pet.sleep', () => {
      petProvider?.sendAction('sleep');
    }),
    vscode.commands.registerCommand('vscode-pet.reset', () => {
      const fresh = loadState(context, true);
      state = fresh;
      saveState(context, fresh);
      petProvider?.sendAction('reset', fresh);
      vscode.window.showInformationMessage('🐾 Pet has been reset!');
    })
  );

  // Passive stat decay — runs every 60 seconds
  const config = vscode.workspace.getConfiguration('vscode-pet');
  const decayRate = config.get<number>('decayRate', 1);

  decayInterval = setInterval(() => {
    petProvider?.sendAction('decay', { rate: decayRate });
  }, 60_000);

  // Detect coding activity — reward pet for commits
  const gitExt = vscode.extensions.getExtension('vscode.git');
  if (gitExt) {
    petProvider?.sendAction('log', { message: '🔗 Git integration active' });
  }

  // Notify when files are saved
  context.subscriptions.push(
    vscode.workspace.onDidSaveTextDocument(() => {
      petProvider?.sendAction('onSave');
    })
  );

  vscode.window.showInformationMessage('🐾 Your pet is ready! Check the sidebar.');
}

export function deactivate() {
  if (decayInterval) {
    clearInterval(decayInterval);
  }
}
