export type PetType = 'cat' | 'dog' | 'bunny';

export function getPetSvg(type: PetType, mood: number): string {
  const color = mood > 60 ? '#4ec9b0' : mood > 30 ? '#dcdcaa' : '#f44747';
  const darkColor = mood > 60 ? '#3ab8a0' : mood > 30 ? '#c8c870' : '#d43030';
  const mouthPath = mood > 60
    ? 'M 59 49 Q 62 53 65 49'   // smile
    : mood > 30
    ? 'M 59 50 L 65 50'          // neutral
    : 'M 59 52 Q 62 49 65 52';  // frown

  switch (type) {
    case 'cat':
      return `
<svg viewBox="0 0 120 100" xmlns="http://www.w3.org/2000/svg">
  <path id="tail" d="M 30 72 Q 10 80 14 65 Q 18 52 26 60"
        fill="none" stroke="${color}" stroke-width="4" stroke-linecap="round"/>
  <ellipse cx="60" cy="68" rx="28" ry="20" fill="${color}"/>
  <circle cx="62" cy="42" r="20" fill="${color}"/>
  <polygon points="46,28 40,16 52,22" fill="${color}"/>
  <polygon points="78,28 84,16 72,22" fill="${color}"/>
  <polygon points="47,27 43,19 51,23" fill="#ce9178"/>
  <polygon points="77,27 81,19 73,23" fill="#ce9178"/>
  <circle id="eyeL" cx="55" cy="40" r="4" fill="#1e1e1e"/>
  <circle id="eyeR" cx="69" cy="40" r="4" fill="#1e1e1e"/>
  <circle cx="56.5" cy="39" r="1.5" fill="#ffffff"/>
  <circle cx="70.5" cy="39" r="1.5" fill="#ffffff"/>
  <polygon points="62,46 59.5,48.5 64.5,48.5" fill="#ce9178"/>
  <path id="mouth" d="${mouthPath}" fill="none" stroke="#1e1e1e"
        stroke-width="1.5" stroke-linecap="round"/>
  <line x1="40" y1="46" x2="56" y2="47" stroke="#858585" stroke-width="0.8" opacity="0.6"/>
  <line x1="40" y1="49" x2="56" y2="49" stroke="#858585" stroke-width="0.8" opacity="0.6"/>
  <line x1="68" y1="47" x2="84" y2="46" stroke="#858585" stroke-width="0.8" opacity="0.6"/>
  <line x1="68" y1="49" x2="84" y2="49" stroke="#858585" stroke-width="0.8" opacity="0.6"/>
  <ellipse cx="40" cy="84" rx="9" ry="6" fill="${darkColor}"/>
  <ellipse cx="80" cy="84" rx="9" ry="6" fill="${darkColor}"/>
</svg>`;

    case 'dog':
      return `
<svg viewBox="0 0 120 100" xmlns="http://www.w3.org/2000/svg">
  <ellipse cx="60" cy="68" rx="30" ry="20" fill="${color}"/>
  <circle cx="60" cy="42" r="21" fill="${color}"/>
  <ellipse cx="42" cy="32" rx="8" ry="14" fill="${darkColor}" transform="rotate(-15, 42, 32)"/>
  <ellipse cx="78" cy="32" rx="8" ry="14" fill="${darkColor}" transform="rotate(15, 78, 32)"/>
  <circle id="eyeL" cx="53" cy="39" r="4.5" fill="#1e1e1e"/>
  <circle id="eyeR" cx="67" cy="39" r="4.5" fill="#1e1e1e"/>
  <circle cx="54.5" cy="38" r="1.5" fill="#ffffff"/>
  <circle cx="68.5" cy="38" r="1.5" fill="#ffffff"/>
  <ellipse cx="60" cy="50" rx="7" ry="5" fill="${darkColor}"/>
  <circle cx="57.5" cy="48.5" r="2" fill="#1e1e1e"/>
  <circle cx="62.5" cy="48.5" r="2" fill="#1e1e1e"/>
  <path id="mouth" d="${mouthPath}" fill="none" stroke="#1e1e1e"
        stroke-width="1.5" stroke-linecap="round"/>
  <path d="M 85 65 Q 100 55 98 70 Q 96 80 88 75" fill="none"
        stroke="${color}" stroke-width="4" stroke-linecap="round"/>
  <ellipse cx="38" cy="84" rx="10" ry="6" fill="${darkColor}"/>
  <ellipse cx="82" cy="84" rx="10" ry="6" fill="${darkColor}"/>
</svg>`;

    case 'bunny':
      return `
<svg viewBox="0 0 120 100" xmlns="http://www.w3.org/2000/svg">
  <ellipse cx="45" cy="26" rx="7" ry="20" fill="${color}" transform="rotate(-10, 45, 26)"/>
  <ellipse cx="75" cy="26" rx="7" ry="20" fill="${color}" transform="rotate(10, 75, 26)"/>
  <ellipse cx="45" cy="28" rx="3" ry="14" fill="#ce9178" transform="rotate(-10, 45, 28)"/>
  <ellipse cx="75" cy="28" rx="3" ry="14" fill="#ce9178" transform="rotate(10, 75, 28)"/>
  <ellipse cx="60" cy="68" rx="28" ry="18" fill="${color}"/>
  <circle cx="60" cy="44" r="22" fill="${color}"/>
  <circle id="eyeL" cx="52" cy="40" r="4" fill="#1e1e1e"/>
  <circle id="eyeR" cx="68" cy="40" r="4" fill="#1e1e1e"/>
  <circle cx="53.5" cy="39" r="1.5" fill="#ffffff"/>
  <circle cx="69.5" cy="39" r="1.5" fill="#ffffff"/>
  <circle cx="60" cy="49" r="4" fill="#ce9178"/>
  <path id="mouth" d="${mouthPath}" fill="none" stroke="#1e1e1e"
        stroke-width="1.5" stroke-linecap="round"/>
  <line x1="38" y1="47" x2="54" y2="48" stroke="#858585" stroke-width="0.8" opacity="0.5"/>
  <line x1="66" y1="48" x2="82" y2="47" stroke="#858585" stroke-width="0.8" opacity="0.5"/>
  <circle cx="60" cy="78" r="6" fill="#ffffff" opacity="0.4"/>
  <ellipse cx="38" cy="84" rx="9" ry="6" fill="${darkColor}"/>
  <ellipse cx="82" cy="84" rx="9" ry="6" fill="${darkColor}"/>
</svg>`;
  }
}
