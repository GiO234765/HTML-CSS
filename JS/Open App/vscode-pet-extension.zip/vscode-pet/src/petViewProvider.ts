import * as vscode from 'vscode';
import * as path from 'path';
import { PetState } from './petState';
import { getPetSvg } from './petSprites';
import { getWebviewContent } from './webviewContent';

export class PetViewProvider implements vscode.WebviewViewProvider {
  public static readonly viewType = 'petView';

  private _view?: vscode.WebviewView;
  private _state: PetState;
  private _onStateChange: (state: PetState) => void;
  private _extensionUri: vscode.Uri;

  constructor(
    extensionUri: vscode.Uri,
    initialState: PetState,
    onStateChange: (state: PetState) => void
  ) {
    this._extensionUri = extensionUri;
    this._state = initialState;
    this._onStateChange = onStateChange;
  }

  resolveWebviewView(
    webviewView: vscode.WebviewView,
    _context: vscode.WebviewViewResolveContext,
    _token: vscode.CancellationToken
  ) {
    this._view = webviewView;

    webviewView.webview.options = {
      enableScripts: true,
      localResourceRoots: [
        vscode.Uri.joinPath(this._extensionUri, 'media'),
      ],
    };

    webviewView.webview.html = getWebviewContent(
      webviewView.webview,
      this._extensionUri,
      this._state
    );

    // Handle messages sent from the webview
    webviewView.webview.onDidReceiveMessage((msg: { type: string; state?: PetState }) => {
      if (msg.type === 'stateUpdate' && msg.state) {
        this._state = msg.state;
        this._onStateChange(this._state);
      }
    });
  }

  /** Send an action command to the webview */
  sendAction(action: string, payload?: unknown) {
    this._view?.webview.postMessage({ type: action, payload });
  }
}
