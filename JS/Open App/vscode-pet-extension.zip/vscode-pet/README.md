# 🐾 Pet Companion — VS Code Extension

A virtual pet that lives in your VS Code sidebar. Keep it happy while you code!

## Features

- 🐱 **3 pet types** — cat, dog, or bunny (configurable)
- 📊 **4 stats** — HP, Hunger, Fun, Rest — all decay over time
- 😴 **Offline decay** — your pet gets hungry while VS Code is closed (max 8 hours counted)
- 💾 **File save rewards** — saving a file gives your pet a fun boost
- 🎮 **4 actions** — feed, play, sleep, code
- 🔧 **Commands** — trigger actions from the Command Palette (`Ctrl+Shift+P`)
- ⚙️ **Configurable** — name, pet type, decay rate

## Quick Start

### Run locally (development)

```bash
# 1. Clone / copy these files into a folder
cd vscode-pet

# 2. Install dependencies
npm install

# 3. Compile TypeScript
npm run compile

# 4. Open in VS Code and press F5 to launch Extension Development Host
```

Then look for the **paw icon** (🐾) in the Activity Bar on the left.

### Install as a .vsix package

```bash
# Install vsce if you haven't
npm install -g @vscode/vsce

# Package the extension
vsce package

# Install the generated .vsix
code --install-extension vscode-pet-1.0.0.vsix
```

## Settings

| Setting | Default | Description |
|---|---|---|
| `vscode-pet.petName` | `"Nibbles"` | Your pet's name |
| `vscode-pet.petType` | `"cat"` | `cat`, `dog`, or `bunny` |
| `vscode-pet.decayRate` | `1` | Stat decay speed (0.5–3) |

## Commands (Command Palette)

- `Pet: Feed your pet 🍣`
- `Pet: Play with your pet 🎮`
- `Pet: Put pet to sleep 🌙`
- `Pet: Reset pet stats`

## Project Structure

```
vscode-pet/
├── src/
│   ├── extension.ts        # Activation, commands, decay timer
│   ├── petViewProvider.ts  # Sidebar webview registration
│   ├── petState.ts         # State load/save + offline decay
│   ├── petSprites.ts       # SVG pet illustrations (cat/dog/bunny)
│   └── webviewContent.ts   # Full sidebar HTML + JS
├── media/
│   └── paw.svg             # Activity bar icon
├── package.json
└── tsconfig.json
```

## Adding a New Pet Type

1. Open `src/petSprites.ts`
2. Add a new case to the `switch` in `getPetSvg()`
3. Add the new type to the `petType` enum in `package.json` under `configuration.properties`

## License

MIT
